package tests;

import org.testng.annotations.*;
import org.openqa.selenium.WebDriver;
import pages.LoginPage;
import utils.DriverFactory;

import static org.testng.Assert.*;

public class LoginTest {
    WebDriver driver;
    LoginPage loginPage;

    @BeforeMethod
    public void setUp() {
        driver = DriverFactory.getDriver();
        driver.get("https://practicetestautomation.com/practice-test-login/");
        loginPage = new LoginPage(driver);
    }

    @Test
    public void testValidLogin() {
        loginPage.login("student", "Password123");
        assertTrue(driver.getCurrentUrl().contains("logged-in-successfully"));
    }

    @Test
    public void testInvalidLogin() {
        loginPage.login("invalid", "wrongpass");
        assertTrue(loginPage.getErrorMessage().contains("Your username is invalid!"));
    }

    @Test
    public void testEmptyFields() {
        loginPage.login("", "");
        assertTrue(loginPage.getErrorMessage().contains("Your username is invalid!"));
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
